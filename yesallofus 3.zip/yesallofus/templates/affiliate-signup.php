<?php
/**
 * Template: Affiliate Signup Form
 */
if (!defined('ABSPATH')) exit;

// Get referral code from multiple sources (URL param takes priority)
$ref_code = '';
if (isset($_GET['ref']) && !empty($_GET['ref'])) {
    $ref_code = sanitize_text_field($_GET['ref']);
} elseif (isset($_COOKIE['dltpays_ref']) && !empty($_COOKIE['dltpays_ref'])) {
    $ref_code = sanitize_text_field($_COOKIE['dltpays_ref']);
} elseif (function_exists('WC') && WC()->session) {
    $ref_code = WC()->session->get('dltpays_ref') ?: '';
}

// Get commission rates - stored as JSON array [level1, level2, level3, level4, level5]
$rates = json_decode(get_option('dltpays_commission_rates', '[25,5,3,2,1]'), true) ?: [25,5,3,2,1];
$top_rate = isset($rates[0]) ? intval($rates[0]) : 25;
$store_name = get_bloginfo('name');
$store_id = get_option('dltpays_store_id', '');
?>
<style>
.dltpays-signup-container {
    max-width: 100%;
    width: 100%;
    margin: 0 auto;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}
.dltpays-signup-card {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
    border-radius: 20px;
    padding: 40px;
    color: #fff;
    box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
    max-width: 600px;
    margin: 0 auto;
}

@media (min-width: 768px) {
    .dltpays-signup-card {
        max-width: 100%;
        padding: 48px;
    }
}

@media (max-width: 480px) {
    .dltpays-signup-card {
        padding: 24px;
        border-radius: 16px;
    }
    .dltpays-commission-highlight {
        flex-direction: column;
        text-align: center;
        gap: 12px;
    }
    .dltpays-commission-percent {
        font-size: 44px;
    }
}
.dltpays-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(16, 185, 129, 0.15);
    border: 1px solid rgba(16, 185, 129, 0.3);
    color: #10b981;
    font-size: 12px;
    font-weight: 600;
    padding: 6px 12px;
    border-radius: 50px;
    margin-bottom: 20px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.dltpays-badge svg {
    width: 14px;
    height: 14px;
}
.dltpays-signup-card h2 {
    font-size: 28px;
    font-weight: 700;
    margin: 0 0 8px 0;
    color: #fff;
}
.dltpays-signup-card .subtitle {
    color: #94a3b8;
    font-size: 16px;
    margin: 0 0 32px 0;
    line-height: 1.5;
}
.dltpays-commission-highlight {
    display: flex;
    align-items: center;
    gap: 20px;
    background: rgba(255,255,255,0.05);
    border-radius: 12px;
    padding: 24px;
    margin-bottom: 12px;
}
.dltpays-commission-percent {
    font-size: 52px;
    font-weight: 800;
    background: linear-gradient(135deg, #10b981 0%, #34d399 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    line-height: 1;
    flex-shrink: 0;
}
.dltpays-commission-text {
    display: flex;
    flex-direction: column;
    justify-content: center;
}
.dltpays-commission-text strong {
    display: block;
    color: #fff;
    font-size: 17px;
    font-weight: 600;
    margin-bottom: 4px;
}
.dltpays-commission-text span {
    font-size: 14px;
    color: #94a3b8;
    line-height: 1.3;
}
.dltpays-multi-level-note {
    font-size: 13px;
    color: #64748b;
    margin: 0 0 28px 0;
}
.dltpays-referred-badge {
    display: flex;
    align-items: center;
    gap: 8px;
    background: rgba(59, 130, 246, 0.15);
    border: 1px solid rgba(59, 130, 246, 0.3);
    color: #60a5fa;
    font-size: 13px;
    padding: 10px 14px;
    border-radius: 10px;
    margin-bottom: 24px;
}
.dltpays-referred-badge svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
}
.dltpays-form-group {
    margin-bottom: 20px;
}
.dltpays-form-group label {
    display: block;
    font-size: 13px;
    font-weight: 600;
    color: #e2e8f0;
    margin-bottom: 8px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.dltpays-form-group input[type="text"] {
    width: 100%;
    padding: 14px 16px;
    font-size: 15px;
    background: rgba(255,255,255,0.07);
    border: 2px solid rgba(255,255,255,0.1);
    border-radius: 10px;
    color: #fff;
    transition: all 0.2s;
    box-sizing: border-box;
}
.dltpays-form-group input[type="text"]:focus {
    outline: none;
    border-color: #10b981;
    background: rgba(255,255,255,0.1);
}
.dltpays-form-group input[type="text"]::placeholder {
    color: #64748b;
}
.dltpays-form-group .hint {
    font-size: 12px;
    color: #64748b;
    margin-top: 8px;
    display: flex;
    align-items: center;
    gap: 6px;
}
.dltpays-form-group .hint svg {
    width: 14px;
    height: 14px;
    color: #10b981;
}
.dltpays-checkbox-group {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    margin-bottom: 24px;
}
.dltpays-checkbox-group input[type="checkbox"] {
    width: 18px;
    height: 18px;
    margin-top: 2px;
    accent-color: #10b981;
    flex-shrink: 0;
}
.dltpays-checkbox-group label {
    font-size: 14px;
    color: #94a3b8;
    cursor: pointer;
    line-height: 1.4;
}
.dltpays-checkbox-group a {
    color: #10b981;
    text-decoration: none;
}
.dltpays-checkbox-group a:hover {
    text-decoration: underline;
}
.dltpays-submit-btn {
    width: 100%;
    padding: 16px 24px;
    font-size: 16px;
    font-weight: 600;
    color: #fff;
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}
.dltpays-submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px -10px rgba(16, 185, 129, 0.5);
}
.dltpays-submit-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
}
.dltpays-submit-btn svg {
    width: 18px;
    height: 18px;
}
.dltpays-divider {
    display: flex;
    align-items: center;
    gap: 16px;
    margin: 28px 0;
}
.dltpays-divider::before,
.dltpays-divider::after {
    content: '';
    flex: 1;
    height: 1px;
    background: rgba(255,255,255,0.1);
}
.dltpays-divider span {
    color: #64748b;
    font-size: 13px;
    font-weight: 500;
}
.dltpays-no-wallet-section {
    background: linear-gradient(135deg, rgba(99, 102, 241, 0.1) 0%, rgba(168, 85, 247, 0.1) 100%);
    border: 1px solid rgba(139, 92, 246, 0.3);
    border-radius: 16px;
    padding: 28px 24px;
    text-align: center;
}
.dltpays-no-wallet-section h3 {
    font-size: 20px;
    font-weight: 700;
    color: #fff;
    margin: 0 0 8px 0;
}
.dltpays-no-wallet-section p {
    color: #a5b4fc;
    font-size: 14px;
    margin: 0 0 24px 0;
    line-height: 1.5;
}
.dltpays-yesallofus-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    width: 100%;
    padding: 16px 24px;
    font-size: 16px;
    font-weight: 600;
    color: #fff;
    background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
    box-sizing: border-box;
    white-space: nowrap;
}

@media (max-width: 480px) {
    .dltpays-signup-card {
        padding: 24px 16px;
        border-radius: 16px;
    }
    .dltpays-no-wallet-section {
        padding: 24px 16px;
    }
    .dltpays-yesallofus-btn {
        padding: 14px 16px;
        font-size: 15px;
    }
    .dltpays-commission-highlight {
        flex-direction: column;
        text-align: center;
        gap: 12px;
    }
    .dltpays-commission-percent {
        font-size: 44px;
    }
    .dltpays-social-icon {
        width: 36px;
        height: 36px;
        min-width: 36px;
        min-height: 36px;
    }
    .dltpays-social-icon svg {
        width: 16px;
        height: 16px;
    }
}
.dltpays-yesallofus-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px -10px rgba(139, 92, 246, 0.5);
    color: #fff;
}
.dltpays-yesallofus-btn svg {
    width: 20px;
    height: 20px;
}
.dltpays-social-icons {
    display: flex;
    justify-content: center;
    margin-bottom: 20px;
}
.dltpays-social-icon {
    width: 44px;
    height: 44px;
    min-width: 44px;
    min-height: 44px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 3px solid #1e1e3f;
    flex-shrink: 0;
    aspect-ratio: 1 / 1;
    margin-left: -12px;
    position: relative;
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
}
.dltpays-social-icon:first-child {
    margin-left: 0;
}
.dltpays-social-icon.google { background: #fff; z-index: 5; }
.dltpays-social-icon.apple { background: #000; z-index: 4; }
.dltpays-social-icon.facebook { background: #1877F2; z-index: 3; }
.dltpays-social-icon.twitter { background: #000; z-index: 2; }
.dltpays-social-icon.discord { background: #5865F2; z-index: 1; }
.dltpays-social-icon svg {
    width: 20px;
    height: 20px;
}
.dltpays-trustline-note {
    display: flex;
    align-items: center;
    gap: 10px;
    background: rgba(251, 191, 36, 0.1);
    border: 1px solid rgba(251, 191, 36, 0.2);
    border-radius: 10px;
    padding: 14px;
    margin-top: 20px;
    font-size: 13px;
    color: #fbbf24;
}
.dltpays-trustline-note svg {
    width: 18px;
    height: 18px;
    flex-shrink: 0;
}
.dltpays-trustline-note a {
    color: #fbbf24;
    font-weight: 600;
}
.dltpays-message {
    padding: 14px;
    border-radius: 10px;
    margin-top: 16px;
    font-size: 14px;
    display: none;
}
.dltpays-message.error {
    background: rgba(239, 68, 68, 0.15);
    border: 1px solid rgba(239, 68, 68, 0.3);
    color: #fca5a5;
}
.dltpays-message.success {
    background: rgba(16, 185, 129, 0.15);
    border: 1px solid rgba(16, 185, 129, 0.3);
    color: #6ee7b7;
}
.dltpays-success-card {
    text-align: center;
    display: none;
}
.dltpays-success-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 24px;
}
.dltpays-success-icon svg {
    width: 40px;
    height: 40px;
    color: #fff;
}
.dltpays-success-card h3 {
    font-size: 24px;
    font-weight: 700;
    color: #fff;
    margin: 0 0 8px 0;
}
.dltpays-success-card .success-subtitle {
    color: #94a3b8;
    margin: 0 0 32px 0;
}
.dltpays-link-box {
    background: rgba(255,255,255,0.05);
    border-radius: 10px;
    padding: 4px;
    display: flex;
    gap: 4px;
    margin-bottom: 24px;
}
.dltpays-link-box input {
    flex: 1;
    padding: 12px 14px;
    font-size: 13px;
    background: transparent;
    border: none;
    color: #fff;
    font-family: monospace;
}
.dltpays-link-box input:focus {
    outline: none;
}
.dltpays-copy-btn {
    padding: 12px 20px;
    font-size: 14px;
    font-weight: 600;
    color: #0f172a;
    background: #10b981;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    gap: 6px;
}
.dltpays-copy-btn:hover {
    background: #34d399;
}
.dltpays-copy-btn.copied {
    background: #6ee7b7;
}
.dltpays-copy-btn svg {
    width: 16px;
    height: 16px;
}
.dltpays-dashboard-link {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    color: #10b981;
    font-weight: 600;
    text-decoration: none;
    font-size: 15px;
}
.dltpays-dashboard-link:hover {
    color: #34d399;
}
.dltpays-dashboard-link svg {
    width: 18px;
    height: 18px;
}
</style>

<div class="dltpays-signup-container">
    <div class="dltpays-signup-card">
        <div class="dltpays-form-state">
            <div class="dltpays-badge">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
                </svg>
                Instant Payouts
            </div>
            
            <h2>Become an Affiliate</h2>
            <p class="subtitle">Promote <?php echo esc_html($store_name); ?> and earn commissions paid instantly to your wallet.</p>
            
            <div class="dltpays-commission-highlight">
                <div class="dltpays-commission-percent"><?php echo $top_rate; ?>%</div>
                <div class="dltpays-commission-text">
                    <strong>Commission Rate</strong>
                    <span>Paid in RLUSD on every sale</span>
                </div>
            </div>
            <p class="dltpays-multi-level-note">Plus earn on 5 levels when you recruit affiliates</p>
            
            <?php if ($ref_code): ?>
            <div class="dltpays-referred-badge">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
                    <circle cx="9" cy="7" r="4"/>
                    <path d="M22 21v-2a4 4 0 0 0-3-3.87"/>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                </svg>
                Referred by: <strong style="margin-left: 4px;"><?php echo esc_html($ref_code); ?></strong>
            </div>
            <?php endif; ?>
            
            <!-- No Wallet Section -->
            <div class="dltpays-no-wallet-section">
                <div class="dltpays-social-icons">
                    <div class="dltpays-social-icon google">
                        <svg viewBox="0 0 24 24">
                            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                        </svg>
                    </div>
                    <div class="dltpays-social-icon apple">
                        <svg viewBox="0 0 24 24" fill="#fff">
                            <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
                        </svg>
                    </div>
                    <div class="dltpays-social-icon facebook">
                        <svg viewBox="0 0 24 24" fill="#fff">
                            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                        </svg>
                    </div>
                    <div class="dltpays-social-icon twitter">
                        <svg viewBox="0 0 24 24" fill="#fff">
                            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                        </svg>
                    </div>
                    <div class="dltpays-social-icon discord">
                        <svg viewBox="0 0 24 24" fill="#fff">
                            <path d="M20.317 4.37a19.791 19.791 0 00-4.885-1.515.074.074 0 00-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 00-5.487 0 12.64 12.64 0 00-.617-1.25.077.077 0 00-.079-.037A19.736 19.736 0 003.677 4.37a.07.07 0 00-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 00.031.057 19.9 19.9 0 005.993 3.03.078.078 0 00.084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 00-.041-.106 13.107 13.107 0 01-1.872-.892.077.077 0 01-.008-.128 10.2 10.2 0 00.372-.292.074.074 0 01.077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 01.078.01c.12.098.246.198.373.292a.077.077 0 01-.006.127 12.299 12.299 0 01-1.873.892.077.077 0 00-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 00.084.028 19.839 19.839 0 006.002-3.03.077.077 0 00.032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 00-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
                        </svg>
                    </div>
                </div>
                <h3>No wallet? No XRP? No problem.</h3>
                <p>Sign up with Google, Apple, or social accounts. We'll create your wallet instantly.</p>
                <a href="https://yesallofus.com/affiliate-dashboard?store=<?php echo esc_attr($store_id); ?><?php echo $ref_code ? '&ref=' . esc_attr($ref_code) : ''; ?>" class="dltpays-yesallofus-btn">
    Sign Up
</a>
            </div>
            
            <div class="dltpays-divider">
                <span>or enter wallet manually</span>
            </div>
            
            <form id="dltpays-signup" method="post">
                <div class="dltpays-form-group">
                    <label for="dltpays-wallet">Your XRPL Wallet</label>
                    <input 
                        type="text" 
                        id="dltpays-wallet" 
                        name="wallet_address" 
                        placeholder="rXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" 
                        required 
                        pattern="^r[1-9A-HJ-NP-Za-km-z]{25,34}$"
                        autocomplete="off"
                    >
                    <div class="hint">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                        </svg>
                        Works with Xaman, Crossmark, or any XRPL wallet
                    </div>
                </div>
                
                <input type="hidden" id="dltpays-currency" name="currency" value="RLUSD">
                <input type="hidden" name="referral_code" id="dltpays-parent-ref" value="<?php echo esc_attr($ref_code); ?>">
                
                <div class="dltpays-checkbox-group">
                    <input type="checkbox" id="dltpays-terms" name="terms" required>
                    <label for="dltpays-terms">
                        I agree to the <a href="https://yesallofus.com/affiliate-terms" target="_blank">Affiliate Terms</a> and have an RLUSD trustline
                    </label>
                </div>
                
                <button type="submit" class="dltpays-submit-btn">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
                    </svg>
                    Start Earning
                </button>
                
                <div class="dltpays-trustline-note">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"/>
                        <line x1="12" y1="8" x2="12" y2="12"/>
                        <line x1="12" y1="16" x2="12.01" y2="16"/>
                    </svg>
                    <span>RLUSD requires a trustline. <a href="https://yesallofus.com/trustline" target="_blank">Setup guide →</a></span>
                </div>
                
                <div class="dltpays-message"></div>
            </form>
        </div>
        
        <div class="dltpays-success-card">
            <div class="dltpays-success-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                    <path d="M20 6L9 17l-5-5"/>
                </svg>
            </div>
            <h3>You're In!</h3>
            <p class="success-subtitle">Start sharing your link and earning commissions.</p>
            
            <div class="dltpays-link-box">
                <input type="text" id="dltpays-ref-link" readonly>
                <button type="button" class="dltpays-copy-btn" onclick="dltpaysCopyLink(this)">
                    <svg class="copy-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                    </svg>
                    <svg class="check-icon" style="display:none" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M20 6L9 17l-5-5"/>
                    </svg>
                    <span>Copy</span>
                </button>
            </div>
            
            <a href="https://yesallofus.com/affiliate-dashboard" class="dltpays-dashboard-link">
                View Dashboard
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
            </a>
        </div>
    </div>
</div>

<script>
function dltpaysCopyLink(btn) {
    const input = document.getElementById('dltpays-ref-link');
    navigator.clipboard.writeText(input.value).then(function() {
        btn.classList.add('copied');
        btn.querySelector('.copy-icon').style.display = 'none';
        btn.querySelector('.check-icon').style.display = 'block';
        btn.querySelector('span').textContent = 'Copied!';
        
        setTimeout(function() {
            btn.classList.remove('copied');
            btn.querySelector('.copy-icon').style.display = 'block';
            btn.querySelector('.check-icon').style.display = 'none';
            btn.querySelector('span').textContent = 'Copy';
        }, 2000);
    });
}
</script>