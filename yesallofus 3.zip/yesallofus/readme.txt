=== YesAllofUs - Instant RLUSD Commissions ===
Contributors: yesallofus
Donate link: https://yesallofus.com
Tags: affiliate, woocommerce, rlusd, commission, referral
Requires at least: 5.8
Tested up to: 6.9
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Instant affiliate commission payouts via RLUSD stablecoin on the XRP Ledger. No monthly fees. 5-level MLM structure.

== Description ==

**YesAllofUs** transforms your WooCommerce store into a powerful affiliate marketing platform with instant commission payouts using RLUSD stablecoin on the XRP Ledger.

= Why YesAllofUs? =

Traditional affiliate platforms make you wait 30-90 days for commission payouts. YesAllofUs pays your affiliates **instantly** - within seconds of a completed sale.

= Key Features =

* **Instant Payouts** - Affiliates receive commissions in seconds, not months
* **RLUSD Stablecoin** - USD-pegged stablecoin on the XRP Ledger (no crypto volatility)
* **5-Level MLM Structure** - Reward your entire referral chain
* **Zero Monthly Fees** - Pay only when you make sales
* **Non-Custodial** - You control your own wallet
* **Xaman Wallet Integration** - Secure mobile wallet with push notifications
* **Payout Batching** - Reduce transaction fees by batching commissions
* **Customizable Rates** - Set commission percentages for each level

= How It Works =

1. **Install & Connect** - Install the plugin and connect your Xaman wallet
2. **Fund Your Wallet** - Add XRP and set up RLUSD trustline
3. **Share Referral Links** - Affiliates sign up and get unique referral codes
4. **Automatic Tracking** - Plugin tracks referrals via cookies
5. **Instant Payouts** - When orders complete, commissions pay out automatically

= Commission Structure =

Default 5-level commission rates (customizable):
* Level 1 (Direct referrer): 25%
* Level 2: 5%
* Level 3: 3%
* Level 4: 2%
* Level 5: 1%

= Requirements =

* WooCommerce 5.0 or higher
* Xaman mobile wallet app (free)
* Small amount of XRP for transaction fees (~$3-5)
* RLUSD for affiliate payouts

= External Services =

This plugin connects to the following external services:

**YesAllofUs API (api.dltpays.com)**
* Purpose: Process affiliate registrations, track commissions, and execute payouts
* Data sent: Store URL, admin email, wallet address, order totals, referral codes
* Privacy policy: https://yesallofus.com/privacy
* Terms of service: https://yesallofus.com/terms

**XRP Ledger**
* Purpose: Execute RLUSD stablecoin payments to affiliates
* Data sent: Wallet addresses, payment amounts
* More info: https://xrpl.org

**Xaman Wallet**
* Purpose: Secure wallet connection and transaction signing
* Data sent: Connection requests, transaction payloads
* Privacy policy: https://xaman.app/privacy

== Installation ==

1. Upload the `yesallofus` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **YesAllofUs > Settings** in your WordPress admin
4. Click "Xaman Mobile App" to connect your wallet
5. Scan the QR code with your Xaman app
6. Fund your wallet with XRP and set up RLUSD trustline
7. Start sharing your affiliate signup page!

= Minimum Requirements =

* WordPress 5.8 or greater
* WooCommerce 5.0 or greater
* PHP version 7.4 or greater
* MySQL version 5.6 or greater

== Frequently Asked Questions ==

= What is RLUSD? =

RLUSD is a USD-pegged stablecoin issued by Ripple on the XRP Ledger. 1 RLUSD always equals $1 USD, so affiliates don't have to worry about cryptocurrency price volatility.

= Do I need cryptocurrency experience? =

No! The plugin guides you through the entire setup process. You just need to download the free Xaman wallet app and follow the on-screen instructions.

= How much does it cost? =

There are no monthly fees. YesAllofUs charges a small percentage of commissions paid out (not your sales). You keep 100% of your product revenue.

= How fast are payouts? =

Payouts are processed within seconds of an order being marked as complete in WooCommerce. Affiliates see funds in their wallet almost instantly.

= Can I customize commission rates? =

Yes! You can set custom commission percentages for each of the 5 levels from the Settings page.

= What if I want to batch payouts instead of instant? =

You can configure payout batching in Settings. Choose to accumulate commissions until they reach a minimum threshold ($5-$100) or batch by schedule (daily, weekly, etc.).

= Is my money safe? =

Yes. YesAllofUs is non-custodial - you control your own wallet. We never have access to your funds. You approve each payout via the Xaman app.

= What wallets are supported? =

Currently, we support Xaman (formerly XUMM) mobile wallet. Additional wallet support coming soon.

= Can affiliates track their earnings? =

Yes! Affiliates can view their earnings dashboard at yesallofus.com/affiliate after signing up.

== Screenshots ==

1. Dashboard - Overview of your affiliate program performance
2. Settings - Connect your wallet and configure commission rates
3. Affiliate Signup - Beautiful signup form for your affiliates
4. Xaman Connection - Easy QR code scanning to connect wallet
5. Payout History - Track all commission payouts

== Changelog ==

= 1.0.0 =
* Initial release
* Xaman wallet integration
* 5-level MLM commission structure
* Instant RLUSD payouts
* Payout batching (threshold and schedule)
* Affiliate signup shortcodes
* WooCommerce order tracking
* Referral cookie tracking

== Upgrade Notice ==

= 1.0.0 =
Initial release of YesAllofUs - Instant RLUSD Affiliate Commissions.

== Privacy Policy ==

YesAllofUs collects and processes the following data:

**Store Data:**
* Store URL and name
* Admin email address
* Connected wallet address

**Affiliate Data:**
* Wallet addresses
* Referral codes
* Commission earnings

**Order Data:**
* Order totals (not product details)
* Referral codes associated with orders

All data is processed in accordance with our privacy policy at https://yesallofus.com/privacy

No personal customer data (names, addresses, payment details) is ever sent to our servers.
